/**
 * Read an analog voltage representing a current value from an
 * *Allegro ACS712* hall effect current sensor and print the
 * read values on a serial LCD.
 *
 * License: not applicable
 * Author: Joseph Paul <joseph@sehrgute.software>
 * URL: http://archive.fabacademy.org/archives/2017/fablaberfindergarden/students/260/fabacademy/week-13/
 */

#define MV_PER_MA 0.185                // Our ACS712 outputs 185mv/A according to the datasheet
#define VCC 5000
#define CURRENT_MAX (VCC/2)/MV_PER_MA  // mA corresponding to a 5.0V reading
#define CURRENT_MIN -CURRENT_MAX       // mA corresponding to a 0.0V reading

#include <avr/io.h>
#include <avr/delay.h>

#include "current-display.h"
#include "SoftwareSerial.h"

// Serial buffers
volatile char *outbuf[32];

// Analog  value
int raw;
char line_0[8];
char line_1[8];

int main(void)
{
    // Setup ADC
    adc_init();
    _delay_ms(20);

    // Setup serial communication
    DDRB |= (1<<PA1);               // Set TXPIN as output
    softSerialBegin(9600);
    _delay_ms(20);

    print("Hello from current-sensor!\n");
    _delay_ms(20);

    for (;;) {
        raw = adc_read();

        // First LCD line
        sprintf(line_0, "%i4mA", as_current(raw));
        lcd_print(0, line_0);
        print("\n");

        // Second LCD line
        sprintf(line_1, "%i4mW", as_current(raw)*VCC/1000);
        lcd_print(1, line_1);
        print("\n");

        _delay_ms(500);
    }

    return 0;
}

/**
 * Print out a string via UART
 */
void print(char what[])
{
    for (int i = 0; i < strlen(what); i++) {
        softSerialWrite(what[i]);
    }
}

/**
 * Enable the ADC, set mode and channel.
 */
void adc_init()
{
    ADMUX = (0 << REFS1) | (0 << REFS0)  // VCC ref
      | (0 << MUX5) | (0 << MUX4) | (0 << MUX3) | (0 << MUX2) | (1 << MUX1) | (1 << MUX0);  // PA3 (ADC3)
    ADCSRA = (1 << ADEN)  // enable
      | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);  // prescaler /128
}

/**
 * Read the ADC and return a 10-bit value as integer.
 *
 * @return int
 */
int adc_read()
{
    ADCSRA |= (1 << ADSC);  // initiate adc reading
    while (ADCSRA & (1 << ADSC));  // wait for completion

    byte less_significant = ADCL;  // Read ADC registers, ADCL has to be read first
    return less_significant | ADCH << 8;
}

/**
 * Print given string on given line of an 8-char
 * serial LCD from iteadstudio.com
 *
 * @param line Line number (0|1)
 * @param text
 */
void lcd_print(byte line, char text[8]) {
    // Go to start of line
    char start[6];
    sprintf(start, "sd%i,0;", line);
    print(start);
    // _delay_ms(5);

    // Clear line
    print("ss        ;");
    // _delay_ms(5);

    // Go to start again
    print(start);
    // _delay_ms(5);

    // Print actual message
    char message[11];
    sprintf(message, "ss%s;", text);
    print(message);
    // _delay_ms(5);
}

/**
 * Express analog reading (0-1023) as mA current.
 *
 * @param  raw [description]
 * @return     [description]
 */
int as_current(int raw) {
    return raw * (CURRENT_MAX - CURRENT_MIN) / 1023 + CURRENT_MIN;
}
